angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {
})

.controller('MainCtrl', function($scope, $http) {
 $http.get('butlers.json').then(function(resp) {
  $scope.User = resp.data.User;
  $scope.PaymentHistory = resp.data.User.PaymentHistory.History;
    console.log('Success', resp);
    // For JSON responses, resp.data contains the result
  }, function(err) {
    console.error('ERR', err);
    // err.status will contain the status code
  })
})





